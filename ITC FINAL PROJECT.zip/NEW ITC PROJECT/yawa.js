function handleSubmit(event) {
    event.preventDefault();
    const successMessage = document.querySelector('.success-message');
    successMessage.style.display = 'block';
    successMessage.textContent = 'Thank you! Your message has been sent successfully.';
    event.target.reset();
}

